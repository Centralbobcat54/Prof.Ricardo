package br.com.bibliotecajogos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaJogosApplication {
    public static void main(String[] args) {
        SpringApplication.run(BibliotecaJogosApplication.class, args);
    }
}
